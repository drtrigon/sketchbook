There is only a Makefile for this example, no code, as the Windows version can be built for Linux. Copy Transmitter.cpp from examples/WINX86/Local/EthernetTCP/RemoteWorker/Transmitter.
