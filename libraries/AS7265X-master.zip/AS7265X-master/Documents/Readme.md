Useful documents about the AS7265X 18-channel 20 FWHM photospectrometer
