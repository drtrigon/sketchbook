AS7265X Smart Spectral Sensor Suite

Repository for Arduino sketches for AMS' AS7265X 3-chip suite of smart spectral sensors. I am using a custom hardware solution described in more detail [here](https://hackaday.io/project/143014-compact-25-spectrometer). Here is the custom pcb:

![custombuild](https://user-images.githubusercontent.com/6698410/39849977-e81ad8fa-53c3-11e8-94f1-4f271d90e6a1.jpg)

![breadboard](https://user-images.githubusercontent.com/6698410/41726505-2caaf03e-7527-11e8-9acb-1d634d8ec81c.jpg)

Now for sale at [Tindie](https://www.tindie.com/products/onehorse/as7265x-spectrometer/).
