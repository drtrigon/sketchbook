/*****************************************************************************
* | File      	:	EPD_1in54c.cpp
* | Author      :   Waveshare team
* | Function    :
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2018-06-06
* | Info        :   Basic version
*
******************************************************************************/
#include <stdlib.h>
#include "EPD_1in54c.h"
#include "Debug.h"
#include "GUI_Paint.h"

const unsigned char lut_vcom0[] = {
    0x0E, 0x14, 0x01, 0x0A, 0x06, 0x04, 0x0A, 0x0A,
    0x0F, 0x03, 0x03, 0x0C, 0x06, 0x0A, 0x00
};

const unsigned char lut_w[] = {
    0x0E, 0x14, 0x01, 0x0A, 0x46, 0x04, 0x8A, 0x4A,
    0x0F, 0x83, 0x43, 0x0C, 0x86, 0x0A, 0x04
};

const unsigned char lut_b[] = {
    0x0E, 0x14, 0x01, 0x8A, 0x06, 0x04, 0x8A, 0x4A,
    0x0F, 0x83, 0x43, 0x0C, 0x06, 0x4A, 0x04
};

const unsigned char lut_g1[] = {
    0x8E, 0x94, 0x01, 0x8A, 0x06, 0x04, 0x8A, 0x4A,
    0x0F, 0x83, 0x43, 0x0C, 0x06, 0x0A, 0x04
};

const unsigned char lut_g2[] = {
    0x8E, 0x94, 0x01, 0x8A, 0x06, 0x04, 0x8A, 0x4A,
    0x0F, 0x83, 0x43, 0x0C, 0x06, 0x0A, 0x04
};

const unsigned char lut_vcom1[] = {
    0x03, 0x1D, 0x01, 0x01, 0x08, 0x23, 0x37, 0x37,
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

const unsigned char lut_red0[] = {
    0x83, 0x5D, 0x01, 0x81, 0x48, 0x23, 0x77, 0x77,
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

const unsigned char lut_red1[] = {
    0x03, 0x1D, 0x01, 0x01, 0x08, 0x23, 0x37, 0x37,
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

void EPD1IN54C::EPD_Reset(void)
{
    EPD_RST_1;
    Dev->Dev_Delay_ms(200);
    EPD_RST_0;
    Dev->Dev_Delay_ms(200);
    EPD_RST_1;
    Dev->Dev_Delay_ms(200);
}

/*******************************************************************************
function:
		Write register address and data
*******************************************************************************/
void EPD1IN54C::EPD_SendCommand(UBYTE Reg)
{
    EPD_DC_0;
    EPD_CS_0;
    SPI_Write_Byte(Reg);
    EPD_CS_1;
}

void EPD1IN54C::EPD_SendData(UBYTE Data)
{
    EPD_DC_1;
    EPD_CS_0;
    SPI_Write_Byte(Data);
    EPD_CS_1;
}

/**
 *  @brief: Wait until the busy_pin goes LOW
 */
void EPD1IN54C::EPD_WaitUntilIdle(void)
{
    while(EPD_BUSY_RD == 0) {
        Dev->Dev_Delay_ms(100);
    }
    DEBUG("e-paper free busy...\n");
}

/**
 *  @brief: set the look-up tables
 */
void EPD1IN54C::EPD_SetLutBw(void)
{
    UWORD count;
    EPD_SendCommand(0x20);         //g vcom
    for(count = 0; count < 15; count++) {
        EPD_SendData(lut_vcom0[count]);
    }
    EPD_SendCommand(0x21);        //g ww --
    for(count = 0; count < 15; count++) {
        EPD_SendData(lut_w[count]);
    }
    EPD_SendCommand(0x22);         //g bw r
    for(count = 0; count < 15; count++) {
        EPD_SendData(lut_b[count]);
    }
    EPD_SendCommand(0x23);         //g wb w
    for(count = 0; count < 15; count++) {
        EPD_SendData(lut_g1[count]);
    }
    EPD_SendCommand(0x24);         //g bb b
    for(count = 0; count < 15; count++) {
        EPD_SendData(lut_g2[count]);
    }
}

void EPD1IN54C::EPD_SetLutRed(void)
{
    UWORD count;
    EPD_SendCommand(0x25);
    for(count = 0; count < 15; count++) {
        EPD_SendData(lut_vcom1[count]);
    }
    EPD_SendCommand(0x26);
    for(count = 0; count < 15; count++) {
        EPD_SendData(lut_red0[count]);
    }
    EPD_SendCommand(0x27);
    for(count = 0; count < 15; count++) {
        EPD_SendData(lut_red1[count]);
    }
}

UBYTE EPD1IN54C::EPD_Init(void)
{
    Dev->System_Init();

    EPD_Reset();

    EPD_SendCommand(POWER_SETTING);
    EPD_SendData(0x07);
    EPD_SendData(0x00);
    EPD_SendData(0x08);
    EPD_SendData(0x00);
    EPD_SendCommand(BOOSTER_SOFT_START);
    EPD_SendData(0x17);
    EPD_SendData(0x17);
    EPD_SendData(0x17);
    EPD_SendCommand(POWER_ON);

    EPD_WaitUntilIdle();

    EPD_SendCommand(PANEL_SETTING);
    EPD_SendData(0x0f);
    EPD_SendData(0x0d);
    EPD_SendCommand(VCOM_AND_DATA_INTERVAL_SETTING);
    EPD_SendData(0xF7);
    // EPD_SendCommand(PLL_CONTROL);
    // EPD_SendData(0x39);
    EPD_SendCommand(TCON_RESOLUTION);  //set x and y
    EPD_SendData(0x98);            //x
    EPD_SendData(0x00);            //y High eight
    EPD_SendData(0x98);            //y Low eight
    EPD_SendCommand(VCM_DC_SETTING_REGISTER); //VCOM
    EPD_SendData(0xf7);

    EPD_SetLutBw();
    EPD_SetLutRed();

    return 0;
}

void EPD1IN54C::EPD_Clear(void)
{
    UWORD Width = (EPD_WIDTH % 8 == 0)? (EPD_WIDTH / 8 ): (EPD_WIDTH / 8 + 1);
    UWORD Height = EPD_HEIGHT;

    //send black data
    EPD_SendCommand(DATA_START_TRANSMISSION_1);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(0xFF);
        }
    }
    Dev->Dev_Delay_ms(2);

    //send red data
    EPD_SendCommand(DATA_START_TRANSMISSION_2);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(0xFF);
        }
    }
    Dev->Dev_Delay_ms(2);
}

void EPD1IN54C::EPD_Display(void)
{
    UWORD Width, Height;
    Width = (EPD_WIDTH % 8 == 0)? (EPD_WIDTH / 8 ): (EPD_WIDTH / 8 + 1);
    Height = EPD_HEIGHT;
    EPD_SendCommand(DATA_START_TRANSMISSION_1);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(spiram->SPIRAM_RD_Byte(i + j * Width));
        }
    }
    Dev->Dev_Delay_ms(2);

    EPD_SendCommand(DATA_START_TRANSMISSION_2);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(spiram->SPIRAM_RD_Byte(i + j * Width + Paint_Image.Image_Offset));
        }
    }
    Dev->Dev_Delay_ms(2);

    EPD_SendCommand(DISPLAY_REFRESH);
    EPD_WaitUntilIdle();
}

void EPD1IN54C::EPD_Sleep(void)
{
    EPD_SendCommand(VCOM_AND_DATA_INTERVAL_SETTING);
    EPD_SendData(0x17);
    EPD_SendCommand(VCM_DC_SETTING_REGISTER);         //to solve Vcom drop
    EPD_SendData(0x00);
    EPD_SendCommand(POWER_SETTING);         //power setting
    EPD_SendData(0x02);        //gate switch to external
    EPD_SendData(0x00);
    EPD_SendData(0x00);
    EPD_SendData(0x00);
    EPD_WaitUntilIdle();
    EPD_SendCommand(POWER_OFF);         //power off
}

