/*****************************************************************************
* | File      	:	EPD_2in13b.cpp
* | Author      :   Waveshare team
* | Function    :
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2018-06-07
* | Info        :   Basic version
*
******************************************************************************/
#include <stdlib.h>
#include "EPD_2in9b.h"
#include "Debug.h"
#include "GUI_Paint.h"

/******************************************************************************
function :	Software reset
parameter:
******************************************************************************/
void EPD2IN9B::EPD_Reset(void)
{
    EPD_RST_1;
    Dev->Dev_Delay_ms(200);
    EPD_RST_0;
    Dev->Dev_Delay_ms(200);
    EPD_RST_1;
    Dev->Dev_Delay_ms(200);
}

/******************************************************************************
function :	send command
parameter:
    Reg : Command register
******************************************************************************/
void EPD2IN9B::EPD_SendCommand(UBYTE Reg)
{
    EPD_DC_0;
    EPD_CS_0;
    SPI_Write_Byte(Reg);
    EPD_CS_1;
}

/******************************************************************************
function :	send data
parameter:
    Data : Write data
******************************************************************************/
void EPD2IN9B::EPD_SendData(UBYTE Data)
{
    EPD_DC_1;
    EPD_CS_0;
    SPI_Write_Byte(Data);
    EPD_CS_1;
}

/******************************************************************************
function :	Wait until the busy_pin goes LOW
parameter:
******************************************************************************/
void EPD2IN9B::EPD_WaitUntilIdle(void)
{
    while(EPD_BUSY_RD == 0) {
        Dev->Dev_Delay_ms(100);
    }
    DEBUG("e-paper free busy...\n");
}

/******************************************************************************
function :	Initialize the e-Paper register
parameter:
******************************************************************************/
UBYTE EPD2IN9B::EPD_Init(void)
{
    Dev->System_Init();

    EPD_Reset();

    EPD_SendCommand(BOOSTER_SOFT_START);
    EPD_SendData(0x17);
    EPD_SendData(0x17);
    EPD_SendData(0x17);
    EPD_SendCommand(POWER_ON);
    EPD_WaitUntilIdle();
    EPD_SendCommand(PANEL_SETTING);
    EPD_SendData(0x8F);
    EPD_SendCommand(VCOM_AND_DATA_INTERVAL_SETTING);
    EPD_SendData(0x77);
    EPD_SendCommand(TCON_RESOLUTION);
    EPD_SendData(0x80);
    EPD_SendData(0x01);
    EPD_SendData(0x28);
    EPD_SendCommand(VCM_DC_SETTING_REGISTER);
    EPD_SendData(0X0A);

    return 0;
}

/******************************************************************************
function :	Clear screen
parameter:
******************************************************************************/
void EPD2IN9B::EPD_Clear(void)
{
    EPD_SendCommand(TCON_RESOLUTION);
    EPD_SendData(EPD_WIDTH >> 8);
    EPD_SendData(EPD_WIDTH & 0xff);
    EPD_SendData(EPD_HEIGHT >> 8);
    EPD_SendData(EPD_HEIGHT & 0xff);

    UWORD Width = (EPD_WIDTH % 8 == 0)? (EPD_WIDTH / 8 ): (EPD_WIDTH / 8 + 1);
    UWORD Height = EPD_HEIGHT;

    //send black data
    EPD_SendCommand(DATA_START_TRANSMISSION_1);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(0xFF);
        }
    }
    Dev->Dev_Delay_ms(2);

    //send red data
    EPD_SendCommand(DATA_START_TRANSMISSION_1);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(0xFF);
        }
    }
    Dev->Dev_Delay_ms(2);
}

/******************************************************************************
function :	Setting the display window
parameter:
******************************************************************************/
void EPD2IN9B::EPD_SetWindows(UWORD Xstart, UWORD Ystart, UWORD Width, UWORD Height)
{
    // EPD_SendCommand(PARTIAL_IN);
    EPD_SendCommand(PARTIAL_WINDOW);
    EPD_SendData(Xstart & 0xf8);     // x should be the multiple of 8, the last 3 bit will always be ignored
    EPD_SendData(((Xstart & 0xf8) + Width  - 1) | 0x07);
    EPD_SendData(Ystart >> 8);
    EPD_SendData(Ystart & 0xff);
    EPD_SendData((Ystart + Height - 1) >> 8);
    EPD_SendData((Ystart + Height - 1) & 0xff);
    EPD_SendData(0x01);         // Gates scan both inside and outside of the partial window. (default)
    Dev->Dev_Delay_ms(2);
}

/******************************************************************************
function :	Sends the image buffer in RAM to e-Paper and displays
parameter:
******************************************************************************/
void EPD2IN9B::EPD_Display(void)
{
    UWORD Width, Height;
    Width = (EPD_WIDTH % 8 == 0)? (EPD_WIDTH / 8 ): (EPD_WIDTH / 8 + 1);
    Height = EPD_HEIGHT;

    EPD_SendCommand(DATA_START_TRANSMISSION_1);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(spiram->SPIRAM_RD_Byte(i + j * Width));
        }
    }
    Dev->Dev_Delay_ms(2);
    EPD_SendCommand(PARTIAL_OUT);
    
    EPD_SendCommand(DATA_START_TRANSMISSION_2);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(spiram->SPIRAM_RD_Byte(i + j * Width + Paint_Image.Image_Offset));
        }
    }
    Dev->Dev_Delay_ms(2);
    EPD_SendCommand(PARTIAL_OUT);

    EPD_SendCommand(DISPLAY_REFRESH);
    EPD_WaitUntilIdle();
}

/******************************************************************************
function :	Enter sleep mode
parameter:
******************************************************************************/
void EPD2IN9B::EPD_Sleep(void)
{
    EPD_SendCommand(POWER_OFF);
    EPD_WaitUntilIdle();
    EPD_SendCommand(DEEP_SLEEP);
    EPD_SendData(0xA5);     // check code
}
