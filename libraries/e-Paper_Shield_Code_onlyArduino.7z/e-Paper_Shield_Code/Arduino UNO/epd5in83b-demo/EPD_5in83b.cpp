/*****************************************************************************
* | File      	:	EPD_5in83b.cpp
* | Author      :   Waveshare team
* | Function    :
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2018-06-12
* | Info        :   Basic version
*
******************************************************************************/
#include <stdlib.h>
#include "EPD_5in83b.h"
#include "Debug.h"
#include "GUI_Paint.h"

/******************************************************************************
function :	Software reset
parameter:
******************************************************************************/
void EPD5IN83B::EPD_Reset(void)
{
    EPD_RST_1;
    Dev->Dev_Delay_ms(200);
    EPD_RST_0;
    Dev->Dev_Delay_ms(200);
    EPD_RST_1;
    Dev->Dev_Delay_ms(200);
}

/******************************************************************************
function :	send command
parameter:
    Reg : Command register
******************************************************************************/
void EPD5IN83B::EPD_SendCommand(UBYTE Reg)
{
    EPD_DC_0;
    EPD_CS_0;
    SPI_Write_Byte(Reg);
    EPD_CS_1;
}

/******************************************************************************
function :	send data
parameter:
    Data : Write data
******************************************************************************/
void EPD5IN83B::EPD_SendData(UBYTE Data)
{
    EPD_DC_1;
    EPD_CS_0;
    SPI_Write_Byte(Data);
    EPD_CS_1;
}

/******************************************************************************
function :	Wait until the busy_pin goes LOW
parameter:
******************************************************************************/
void EPD5IN83B::EPD_WaitUntilIdle(void)
{
    while(EPD_BUSY_RD == 0) {      //LOW: idle, HIGH: busy
        Dev->Dev_Delay_ms(100);
    }
}

/******************************************************************************
function :	Turn On Display
parameter:
******************************************************************************/
void EPD5IN83B::EPD_TurnOnDisplay(void)
{
    EPD_SendCommand(DISPLAY_REFRESH);
    Dev->Dev_Delay_ms(100);
    EPD_WaitUntilIdle();
}

/******************************************************************************
function :	Initialize the e-Paper register
parameter:
******************************************************************************/
UBYTE EPD5IN83B::EPD_Init(void)
{
    Dev->System_Init();

    EPD_Reset();
    EPD_SendCommand(POWER_SETTING);
    EPD_SendData(0x37);
    EPD_SendData(0x00);

    EPD_SendCommand(PANEL_SETTING);
    EPD_SendData(0xCF);
    EPD_SendData(0x08);

    EPD_SendCommand(BOOSTER_SOFT_START);
    EPD_SendData(0xC7);
    EPD_SendData(0xCC);
    EPD_SendData(0x28);

    EPD_SendCommand(PLL_CONTROL);
    EPD_SendData(0x3A);     //PLL:  0-15:0x3C, 15+:0x3A

    EPD_SendCommand(TEMPERATURE_CALIBRATION);
    EPD_SendData(0x00);

    EPD_SendCommand(VCOM_AND_DATA_INTERVAL_SETTING);
    EPD_SendData(0x77);

    EPD_SendCommand(TCON_SETTING);
    EPD_SendData(0x22);

    EPD_SendCommand(TCON_RESOLUTION);
    EPD_SendData(EPD_WIDTH >> 8);     //source 640
    EPD_SendData(EPD_WIDTH & 0xff);
    EPD_SendData(EPD_HEIGHT >> 8);     //gate 384
    EPD_SendData(EPD_HEIGHT & 0xff);

    EPD_SendCommand(VCM_DC_SETTING);
    EPD_SendData(0x20);      //decide by LUT file
    
    EPD_SendCommand(0xE5);           //FLASH MODE
    EPD_SendData(0x03);

    EPD_SendCommand(POWER_ON);
    EPD_WaitUntilIdle();
    
    return 0;
}

/******************************************************************************
function :	Clear screen
parameter:
******************************************************************************/
void EPD5IN83B::EPD_Clear(void)
{
    UWORD Width, Height;
    Width = (EPD_WIDTH % 8 == 0)? (EPD_WIDTH / 8 ): (EPD_WIDTH / 8 + 1);
    Height = EPD_HEIGHT;

    EPD_SendCommand(DATA_START_TRANSMISSION_1);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            for(UBYTE k = 0; k < 4; k++) {
                EPD_SendData(0x33);
            }
        }
    }
    // EPD_TurnOnDisplay();
}

/******************************************************************************
function :	Sends the image buffer in RAM to e-Paper and displays
parameter:
******************************************************************************/
void EPD5IN83B::EPD_Display(void)
{
    UBYTE Data_Black, Data_Red, Data;
    UDOUBLE i, j, Width, Height;
    Width = (EPD_WIDTH % 8 == 0)? (EPD_WIDTH / 8 ): (EPD_WIDTH / 8 + 1);
    Height = EPD_HEIGHT;
    DEBUG("Width = ");
    DEBUG(Width);
    DEBUG("\n");
    DEBUG("Height = ");
    DEBUG(Height);
    DEBUG("\n");

    EPD_SendCommand(DATA_START_TRANSMISSION_1);
    for (j = 0; j < Height; j++) {
        for (i = 0; i < Width; i++) {
            Data_Black = spiram->SPIRAM_RD_Byte(UDOUBLE(i + j * Width));
            Data_Red = spiram->SPIRAM_RD_Byte(UDOUBLE(i + j * Width + Paint_Image.Image_Offset));
            for(UBYTE k = 0; k < 8; k++) {
                if ((Data_Red & 0x80) == 0x00) {
                    Data = 0x04;                //red
                } else if ((Data_Black & 0x80) == 0x00) {
                    Data = 0x00;               //black
                } else {
                    Data = 0x03;                //white
                }
                Data = (Data << 4) & 0xFF;
                Data_Black = (Data_Black << 1) & 0xFF;
                Data_Red = (Data_Red << 1) & 0xFF;
                k += 1;

                if((Data_Red & 0x80) == 0x00) {
                    Data |= 0x04;              //red
                } else if ((Data_Black & 0x80) == 0x00) {
                    Data |= 0x00;              //black
                } else {
                    Data |= 0x03;              //white
                }
                Data_Black = (Data_Black << 1) & 0xFF;
                Data_Red = (Data_Red << 1) & 0xFF;
                EPD_SendData(Data);
            }
        }
    }
    EPD_TurnOnDisplay();
}

/******************************************************************************
function :	Enter sleep mode
parameter:
******************************************************************************/
void EPD5IN83B::EPD_Sleep(void)
{
    EPD_SendCommand(POWER_OFF);
    EPD_WaitUntilIdle();
    EPD_SendCommand(DEEP_SLEEP);
    EPD_SendData(0XA5);
}

