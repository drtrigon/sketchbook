/*****************************************************************************
* | File      	:	EPD_4in2.cpp
* | Author      :   Waveshare team
* | Function    :
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2018-06-11
* | Info        :   Basic version
*
******************************************************************************/
#include <stdlib.h>
#include "EPD_4in2.h"
#include "Debug.h"
#include "GUI_Paint.h"

const unsigned char lut_vcom0[] =
{
0x00, 0x17, 0x00, 0x00, 0x00, 0x02,        
0x00, 0x17, 0x17, 0x00, 0x00, 0x02,        
0x00, 0x0A, 0x01, 0x00, 0x00, 0x01,        
0x00, 0x0E, 0x0E, 0x00, 0x00, 0x02,        
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,        
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,        
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,

};
const unsigned char lut_ww[] ={
0x40, 0x17, 0x00, 0x00, 0x00, 0x02,
0x90, 0x17, 0x17, 0x00, 0x00, 0x02,
0x40, 0x0A, 0x01, 0x00, 0x00, 0x01,
0xA0, 0x0E, 0x0E, 0x00, 0x00, 0x02,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,

};
const unsigned char lut_bw[] ={
0x40, 0x17, 0x00, 0x00, 0x00, 0x02,
0x90, 0x17, 0x17, 0x00, 0x00, 0x02,
0x40, 0x0A, 0x01, 0x00, 0x00, 0x01,
0xA0, 0x0E, 0x0E, 0x00, 0x00, 0x02,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      
};

const unsigned char lut_wb[] ={
0x80, 0x17, 0x00, 0x00, 0x00, 0x02,
0x90, 0x17, 0x17, 0x00, 0x00, 0x02,
0x80, 0x0A, 0x01, 0x00, 0x00, 0x01,
0x50, 0x0E, 0x0E, 0x00, 0x00, 0x02,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
             
};

const unsigned char lut_bb[] ={
0x80, 0x17, 0x00, 0x00, 0x00, 0x02,
0x90, 0x17, 0x17, 0x00, 0x00, 0x02,
0x80, 0x0A, 0x01, 0x00, 0x00, 0x01,
0x50, 0x0E, 0x0E, 0x00, 0x00, 0x02,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            
};

/******************************************************************************
function :	Software reset
parameter:
******************************************************************************/
void EPD4IN2::EPD_Reset(void)
{
    EPD_RST_1;
    Dev->Dev_Delay_ms(200);
    EPD_RST_0;
    Dev->Dev_Delay_ms(200);
    EPD_RST_1;
    Dev->Dev_Delay_ms(200);
}

/******************************************************************************
function :	send command
parameter:
    Reg : Command register
******************************************************************************/
void EPD4IN2::EPD_SendCommand(UBYTE Reg)
{
    EPD_DC_0;
    EPD_CS_0;
    SPI_Write_Byte(Reg);
    EPD_CS_1;
}

/******************************************************************************
function :	send data
parameter:
    Data : Write data
******************************************************************************/
void EPD4IN2::EPD_SendData(UBYTE Data)
{
    EPD_DC_1;
    EPD_CS_0;
    SPI_Write_Byte(Data);
    EPD_CS_1;
}

/******************************************************************************
function :	Wait until the busy_pin goes LOW
parameter:
******************************************************************************/
void EPD4IN2::EPD_WaitUntilIdle(void)
{
    while(EPD_BUSY_RD == 0) {      //LOW: idle, HIGH: busy
        Dev->Dev_Delay_ms(100);
    }
}

/******************************************************************************
function :	Turn On Display
parameter:
******************************************************************************/
void EPD4IN2::EPD_TurnOnDisplay(void)
{
    EPD_SendCommand(DISPLAY_REFRESH);
    Dev->Dev_Delay_ms(100);
    EPD_WaitUntilIdle();
}

/******************************************************************************
function :	set the look-up tables
parameter:
******************************************************************************/
void EPD4IN2::EPD_SetLut(void)
{
    UWORD count;
    EPD_SendCommand(LUT_FOR_VCOM);         //g vcom
    for(count=0; count<44; count++) {
        EPD_SendData(lut_vcom0[count]);
    }

    EPD_SendCommand(LUT_WHITE_TO_WHITE);
    for(count=0; count<42; count++) {
        EPD_SendData(lut_ww[count]);
    }

    EPD_SendCommand(LUT_BLACK_TO_WHITE);
    for(count=0; count<42; count++) {
        EPD_SendData(lut_bw[count]);
    }

    EPD_SendCommand(LUT_WHITE_TO_BLACK);
    for(count=0; count<42; count++) {
        EPD_SendData(lut_wb[count]);
    }

    EPD_SendCommand(LUT_BLACK_TO_BLACK);
    for(count=0; count<42; count++) {
        EPD_SendData(lut_bb[count]);
    }
}

/******************************************************************************
function :	Initialize the e-Paper register
parameter:
******************************************************************************/
UBYTE EPD4IN2::EPD_Init(void)
{
    Dev->System_Init();

    EPD_Reset();

    EPD_SendCommand(POWER_SETTING);			//POWER SETTING
    EPD_SendData(0x03);
    EPD_SendData(0x00);
    EPD_SendData(0x2b);
    EPD_SendData(0x2b);

    EPD_SendCommand(BOOSTER_SOFT_START);         //boost soft start
    EPD_SendData(0x17);		//A
    EPD_SendData(0x17);		//B
    EPD_SendData(0x17);		//C

    EPD_SendCommand(POWER_ON);
    EPD_WaitUntilIdle();

    EPD_SendCommand(PANEL_SETTING);			//panel setting
    EPD_SendData(0xbf);		//KW-BF   KWR-AF	BWROTP 0f	BWOTP 1f
    EPD_SendData(0x0d);

    EPD_SendCommand(PLL_CONTROL);			//PLL setting
    EPD_SendData(0x3C);      	// 3A 100HZ   29 150Hz 39 200HZ	31 171HZ

    EPD_SendCommand(0x61);			//resolution setting
    EPD_SendData(0x01);
    EPD_SendData(0x90);       //128
    EPD_SendData(0x01);		//
    EPD_SendData(0x2c);

    EPD_SendCommand(0x82);			//vcom_DC setting
    EPD_SendData(0x28);

    EPD_SendCommand(0X50);			//VCOM AND DATA INTERVAL SETTING
    EPD_SendData(0x97);		//97white border 77black border		VBDF 17|D7 VBDW 97 VBDB 57		VBDF F7 VBDW 77 VBDB 37  VBDR B7
    
    EPD_SetLut();

    return 0;
}

/******************************************************************************
function :	Clear screen
parameter:
******************************************************************************/
void EPD4IN2::EPD_Clear(void)
{
    UWORD Width, Height;
    Width = (EPD_WIDTH % 8 == 0)? (EPD_WIDTH / 8 ): (EPD_WIDTH / 8 + 1);
    Height = EPD_HEIGHT;

    EPD_SendCommand(DATA_START_TRANSMISSION_1);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(0xFF);
        }
    }
    EPD_SendCommand(DATA_START_TRANSMISSION_2);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(0xFF);
        }
    }
}

/******************************************************************************
function :	Sends the image buffer in RAM to e-Paper and displays
parameter:
******************************************************************************/
void EPD4IN2::EPD_Display(void)
{
    UWORD Width, Height;
    Width = (EPD_WIDTH % 8 == 0)? (EPD_WIDTH / 8 ): (EPD_WIDTH / 8 + 1);
    Height = EPD_HEIGHT;
    
    EPD_SendCommand(DATA_START_TRANSMISSION_1);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(0XFF);
        }
    }
    EPD_SendCommand(DATA_START_TRANSMISSION_2);
    for (UWORD j = 0; j < Height; j++) {
        for (UWORD i = 0; i < Width; i++) {
            EPD_SendData(spiram->SPIRAM_RD_Byte(i + j * Width));
        }
    }
    EPD_TurnOnDisplay();
}

/******************************************************************************
function :	Enter sleep mode
parameter:
******************************************************************************/
void EPD4IN2::EPD_Sleep(void)
{
    EPD_SendCommand(POWER_OFF);
    EPD_WaitUntilIdle();
    EPD_SendCommand(DEEP_SLEEP);
    EPD_SendData(0XA5);
}
