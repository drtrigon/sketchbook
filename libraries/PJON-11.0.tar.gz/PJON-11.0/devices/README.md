#### Devices  
This directory is where PJON compatible devices can be shared with other users. The aim is to create a group of "real world" PJON application examples, providing the community with a framework for sharing their crafts.

[LEDAR](sensors/LEDAR/README.md) is the first device published, proposed as a guideline for users submissions.  

Feel free to make a pull request proposing a device you have engineered.
