Alhambra II V1.0A - Pinout

v1.0 rev 2 (Added bitstream select pins)
