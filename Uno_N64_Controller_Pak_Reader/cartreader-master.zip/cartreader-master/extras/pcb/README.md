#### This is the main pcb
   
![image](https://dl.dropboxusercontent.com/s/ta7pjoxn9kirtan/v17pcb.png?dl=1)    

#### The 8bit Flash Adapter is used to program 8bit and 16bit(in 8bit mode) flashroms like the 29F032, 29L3211 or 29LV160, PCB thickness is 1.2mm.   
   
![image](https://dl.dropboxusercontent.com/s/jk2xmjy5bp4jfms/flash_adapter.png?dl=1)    

#### TSOP40_to_DIP36 is an adapter pcb for making homebrew SNES games with the 29F032 family of flashroms   

![image](https://dl.dropboxusercontent.com/s/lfyts5puzsub1be/TSOP40_to_DIP36.gif?dl=1)  

#### With the sd_adapter pcb you can transform the microSD module into a full size sd module by desoldering all the components and solder them to this pcb.    

![image](https://dl.dropboxusercontent.com/s/jcse9iaxm3bbuu6/sd_adapter.pngg?dl=1)    


