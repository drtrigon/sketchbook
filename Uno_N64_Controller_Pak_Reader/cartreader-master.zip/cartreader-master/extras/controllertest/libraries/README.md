Unzip and copy those into your Arduino library folder e.g. C:\Users\sanni\Documents\Arduino\libraries

You can also get the latest versions from their creators page:  
Oled lib: http://www.rinkydinkelectronics.com/library.php?id=79  
