This is my portable N64 Controller Tester edited to run on the Cart Reader Shield.  
The N64 controller's data line is connected to Arduino Mega Pin 7.  
