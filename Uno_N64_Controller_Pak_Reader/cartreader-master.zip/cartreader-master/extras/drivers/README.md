If you have an Arduino with CH341 USB to Serial Chip then you need to install these additional drivers.
