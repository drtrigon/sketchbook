Here are two tools that can byteswap a N64 rom for you.    
