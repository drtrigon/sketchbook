You can use this little program to split a 4MB Nintendo Power dump into the individual roms.  
Get the Java Runtimes from here in case you need them: http://www.java.com/en/download/manual.jsp
