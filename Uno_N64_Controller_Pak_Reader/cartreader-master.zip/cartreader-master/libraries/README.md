Unzip and copy those into your Arduino library folder e.g. C:\Users\sanni\Documents\Arduino\libraries

You can also get the latest versions from their respective github:  
SD lib: https://github.com/greiman/SdFat  
LCD lib: https://github.com/adafruit/Adafruit_SSD1306  
RGB Tools lib: https://github.com/joushx/Arduino-RGB-Tools  
SI5351 lib: https://github.com/etherkit/Si5351Arduino  
