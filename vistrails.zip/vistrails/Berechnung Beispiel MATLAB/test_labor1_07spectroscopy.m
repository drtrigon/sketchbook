%% read measured data from various files

data_full = importdata('Umgebungslicht.txt')
data = data_full.data;
wavelengths = data(:,1);
background = data(:,2);

data_full = importdata('Halogen_UV_ohne_Brille.txt')
data = data_full.data;
reference = data(:,2);

data_full = importdata('Halogen_UV_mitBrille.txt')
data = data_full.data;
signal = data(:,2);

%% calculate the attenuation in dB from the measured data

attenuation = -log10((signal - background)./(reference - background));

%% plot measured data as read from files

subplot(2, 2, 1);
plot(wavelengths, background)
title("background");

subplot(2, 2, 2);
plot(wavelengths, reference)
title("reference");

subplot(2, 2, 3);
plot(wavelengths, signal)
title("signal");

%% plot result of calculation

subplot(2, 2, 4);
plot(wavelengths, attenuation)
title("attenuation");
