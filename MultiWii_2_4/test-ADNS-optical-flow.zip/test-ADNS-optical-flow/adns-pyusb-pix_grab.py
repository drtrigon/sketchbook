#!/usr/bin/python

# https://stackoverflow.com/questions/23229083/acquiring-images-from-a-usb-mouse-single-chip-adns-2700-via-pyusb
# https://www.orangecoat.com/how-to/read-and-decode-data-from-your-mouse-using-this-pyusb-hack
#
# https://github.com/pyusb/pyusb/archive/master.zip
#
# osboxes@osboxes:~$ sudo apt-get install python-matplotlib
#
# ursin@ThinkPad-T440-ursin:~/Downloads/test$ lsusb
# Bus 002 Device 057: ID 046d:c06c Logitech, Inc. Optical Mouse
# Bus 002 Device 063: ID 0461:4d15 Primax Electronics, Ltd Dell Optical Mouse
#
# * try to read form currently connected mouse needs detaching from kernel first - else "device busy"
# * need root permission or udev rule - else "permission denied"
# * not all mouses work properly, dell is ok, logitech not - "pipe error"
#
# ursin@ThinkPad-T440-ursin:~/Downloads/test$ sudo python adns-pyusb-pix_grab.py 

import usb.core
import usb.util
import matplotlib.pyplot as plt
import numpy as np

# decimal vendor and product values
#VENDOR_ID = 6447
#PRODUCT_ID = 2326
# or search instead by the hexidecimal
#VENDOR_ID = 0x046d   # Bus 002 Device 062: ID 046d:c06c Logitech, Inc. Optical Mouse
#PRODUCT_ID = 0xc06c  # Logitech M127, chip: ???
VENDOR_ID = 0x0461   # Bus 002 Device 063: ID 0461:4d15 Primax Electronics, Ltd Dell Optical Mouse
PRODUCT_ID = 0x4d15  # chip: (ADN)S5007

#PIX_GRAB = 0x0D
PIX_GRAB = 0x0B
#PIX_GRAB = 0x13

# find the USB device
device = usb.core.find(idVendor=VENDOR_ID,
                       idProduct=PRODUCT_ID)

# first endpoint
interface = 0
# if the OS kernel already claimed the device, which is most likely true
# thanks to http://stackoverflow.com/questions/8218683/pyusb-cannot-set-configuration
active = device.is_kernel_driver_active(interface)
if active is True:
  # tell the kernel to detach
  device.detach_kernel_driver(interface)

# use the first/default configuration
device.set_configuration()

# claim the device
usb.util.claim_interface(device, interface)

# In order to read the pixel bytes, reset PIX_GRAB by sending a write command
response = device.ctrl_transfer(bmRequestType = 0x40, #Write
                                     bRequest = 0x01,
                                     wValue = 0x0000,
                                     wIndex = PIX_GRAB, #PIX_GRAB register value
                                     data_or_wLength = None
                                     )

# Read all the pixels (360 in this chip)
pixList = []
#for i in range(361):
for i in range(225):
    response = device.ctrl_transfer(bmRequestType = 0xC0, #Read
                                         bRequest = 0x01,
                                         wValue = 0x0000,
                                         wIndex = PIX_GRAB, #PIX_GRAB register value
                                         data_or_wLength = 1
                                         )
    pixList.append(response)

# release the device
#active = True
usb.util.release_interface(device, interface)
if active is True:
  # reattach the device to the OS kernel
  device.attach_kernel_driver(interface)

pixelArray = np.asarray(pixList)
#pixelArray = pixelArray.reshape((19,19))
pixelArray = pixelArray.reshape((15,15))
print(pixelArray)

plt.imshow(pixelArray, interpolation='nearest')
plt.show() 
