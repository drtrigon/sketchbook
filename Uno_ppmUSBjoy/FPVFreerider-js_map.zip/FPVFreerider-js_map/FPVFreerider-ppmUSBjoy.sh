#!/bin/bash

#sudo python js_map.py & export APP_PID=$! ; sleep 1
#echo PID: $APP_PID
#
#./FPVFreerider.x86_64
#
#echo Terminating $APP_PID.
#sudo kill $APP_PID

echo Please enter your password into the dialog box.
#PASSWD=`(zenity --password --title=Authentication)`
PASSWD=`(kdialog --password "Please enter the root password:")`

#kdesudo python js_map.py & export APP_PID=$! ; sleep 1
#sudo -A "python js_map.py & export APP_PID=$! ; sleep 1"
echo -e $PASSWD | sudo -S -- python js_map.py & export APP_PID=$! ; sleep 3
echo PID: $APP_PID

#echo "Move all sticks to all min/max positions, then center them and press OK."
#kdialog --msgbox "Move all sticks to all min/max positions, then center them and press OK."

./FPVFreerider.x86_64

echo Terminating $APP_PID.
#sudo -A "kill $APP_PID"
echo -e $PASSWD | sudo -S -- kill $APP_PID
