# -*- coding: utf-8 -*-

import os
import shutil

os.system("unzip python-uinput-master.zip")

os.system("cd python-uinput-master; python setup.py build")

shutil.copytree("python-uinput-master/build/lib.linux-x86_64-2.7/uinput", "uinput")
shutil.copy("python-uinput-master/build/lib.linux-x86_64-2.7/_libsuinput.so", "_libsuinput.so")

shutil.rmtree("python-uinput-master")
