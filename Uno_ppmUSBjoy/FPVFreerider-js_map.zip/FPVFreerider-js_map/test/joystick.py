# info/source:
#
# https://github.com/tuomasjjrasanen/python-uinput/blob/master/examples/joystick.py
# https://gist.github.com/rdb/8864666

# install/setup:
#
# $ sudo apt-get install python-pip
# $ sudo pip install python-uinput

# run/usage: $ sudo python joystick.py
#
# then check either '/dev/input/js?' or "Joystick settings" 
# (from KDE menu)

# application:
# 
# A. use as input for FPVFreerider (source engine?)
#    1. convert ppmUSBjoy hardware by mapping to other or
#       create just a dummy hardware/joystick that does
#       stepwise movements on all axes (like THIS script)
#       -> RESULT: at least 1 button is needed in order
#                  to get recognized !
#    2. adopt ppmUSBjoy arduino sketch by adding 1 button
#       (dummy; no function) and have ID_INPUT_JOYSTICK=1
#       if needed
#
#    This should be the same for about all software/games 
#    using source engine? by Valve/Steam. You can recognize
#    them by the console output:
#    > Using libudev for joystick management
#
# B. create soundcard/ppm to joystick converter/emulator 
#    like SmartPropoPlus (http://www.smartpropoplus.com/)
#    1. needs an adapter cable to adopt voltage level of 
#       3.3-3.6V to soundcard (about 0.7V) -> voltage 
#       divider needed

import uinput
import time

def main():
    events = (
        uinput.BTN_JOYSTICK,
        uinput.ABS_X + (0, 255, 0, 0),
        uinput.ABS_Y + (0, 255, 0, 0),
        uinput.ABS_Z + (0, 255, 0, 0),
        uinput.ABS_RX + (0, 255, 0, 0),
        uinput.ABS_RY + (0, 255, 0, 0),
        uinput.ABS_RZ + (0, 255, 0, 0),
        )

    with uinput.Device(events) as device:
        print "Joystick created"
        time.sleep(1)
#        for i in range(20):
        i = 0
        while True:
            # syn=False to emit an "atomic" (5, 5) event.
            device.emit(uinput.ABS_X, 5+i, syn=False)
            device.emit(uinput.ABS_Y, 5+i, syn=False)
            device.emit(uinput.ABS_RX, 5+i, syn=False)
            device.emit(uinput.ABS_RY, 5+i)
            device.emit_click(uinput.BTN_JOYSTICK)
            time.sleep(1)
            i += 1

if __name__ == "__main__":
    main()
