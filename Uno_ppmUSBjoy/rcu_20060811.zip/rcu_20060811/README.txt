README for the RC USB Controller by Oleg Semyonov              [2006.08.11]
---------------------------------------------------------------------------

This is a project which implements PPM radio remote control
transmitter-to-USB interface device similar to described here:
http://www.milehighwings.com/usb_cables.htm

This device looks like a standard HID joystick for operating system and
converts up to 8 PPM channels from transmitter into joystick axes and
optionally - buttons. If you know about radio controlled models and their
PC simulators such like FMS, Aerofly Pro Deluxe, RealFlight G2/G3 and
Reflex XTR, and if you are an owner of PPM transmitter box then you
definitely know how to use this device.

There is a lot of such projects around based on different MCUs and
USB drivers. But this is an open-source one. It uses the AVR-USB driver
from Objective Development and low-cost components for hardware.

This project was inspired by an article at Russian-speaking web site
http://www.rcdesign.ru/articles/electronics/rcusb and uses the same
hardware for drop-in firmware replacement. The circuit is included here
for convenience. It does not provide a channel mapping via EEPROM because
it is an open-source one (you may do it yourself) and there is no such
need (all above mentioned simulators have internal channel mapping and
calibration facilities). But it provides smoother control due to accurate
PPM signal handling and filtering options (no jerks). In addition it
optionally translates one of PPM channels into spare MCU pin to have a
kind of servo tester. An optional ADC input driver is also included so
it is possible to do transmitter-like box with resistors yourself and try
to control an RC models using PC simulator. The source code is your best
friend. The main.c and options.h are good starting points to study it.

Have a nice flights!

Oleg Semyonov <os-usb-iar@kbka.net>
