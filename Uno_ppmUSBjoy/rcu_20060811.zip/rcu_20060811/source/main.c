//=============================================================================
// RC USB HID-compatible controller.
// Written by Oleg Semyonov (os-usb-iar@kbka.net), (c) 2006
//
// To be compiled with: IAR Embedded Workbench for AVR 4.20A/W32
// Evaluation version is available at www.iar.com or via direct link
// http://supp.iar.com/FilesPublic/EWMIRROR/002491/EWAVR-EV-420A.exe
//
// $Id: main.c,v 1.8.2.4 2006/08/10 16:04:29 SOY Exp $
//=============================================================================

#include "common.h"

//
// Execution starts here
//
__C_task void main(void)
{
    wdInit();                       // initialize watchdog timer
    usbInit();                      // initialize USB driver
    bootInit();                     // initialize boot loader interface
    inDecoderInit();                // initialize input decoder
    usbDeviceConnect();             // connect USB device to USB bus
    sei();                          // required by USB driver and some interfaces

    while (1)
    {
        wdReset();                  // reset watchdog timer
        inDecoderPoll();            // poll for input data
        outSendData();              // prepare data for USB Interrupt In endpoint
        usbPoll();                  // process USB requests

#if BOOT_SUPPORT_ENABLED
        if (bootRequest())          // jump to boot loader if switch is pressed
        {
            usbDeviceDisconnect();  // disconnect USB device from USB bus
            inDecoderStop();        // stop input decoder interrupts
            bootJump();             // jump to boot loader
        }
#endif
    }
}
