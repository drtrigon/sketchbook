//=============================================================================
// Reflex RC USB device.
//
// PLEASE DO NOT ASK FOR REFLEX INTERFACE SOURCE OR BINARY CODE!
// This code will NEVER be released due to copyright issues.
// Support the author of Reflex - buy the original product.
//
// This module is left here as a sample how to replace
// the output interface using conditional compilation.
//
// $Id: out_reflex.h,v 1.3.2.3 2006/07/20 20:08:42 SOY Exp $
//=============================================================================

#ifndef __OUT_REFLEX_H_INCLUDED__
#define __OUT_REFLEX_H_INCLUDED__

#if OUT_REFLEX

//=============================================================================
// Function prototypes
extern void outSendData(void);

//=============================================================================
// USB Descriptor options and definitions.
// The VID and PID values as well as vendor and device names were taken
// from original REFLEX .inf setup file. Please do not distribute binary
// code with such values.
#define USB_CFG_VENDOR_ID           0x9B, 0x0B
#define USB_CFG_DEVICE_ID           0x12, 0x40
#define USB_CFG_DEVICE_VERSION      0x00, 0x01
#define USB_CFG_VENDOR_NAME         'D', 'i', 'p', 'l', '.', '-', 'I', 'n', 'g', '.', ' ', 'S', 't', 'e', 'f', 'a', 'n', ' ', 'K', 'u', 'n', 'd', 'e'
#define USB_CFG_VENDOR_NAME_LEN     23
#define USB_CFG_DEVICE_NAME         'R', 'E', 'F', 'L', 'E', 'X', ' ', 'R', 'C', ' ', 'U', 'S', 'B', ' ', 'D', 'e', 'v', 'i', 'c', 'e'
#define USB_CFG_DEVICE_NAME_LEN     20
#define USB_CFG_HID_REPORT_DESCRIPTOR_LENGTH    0

#endif  // OUT_REFLEX

#endif  // __OUT_REFLEX_H_INCLUDED__
