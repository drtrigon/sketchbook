//=============================================================================
// Boot Loader interface.
//
// $Id: boot.h,v 1.7.2.3 2006/08/10 16:04:29 SOY Exp $
//=============================================================================

#ifndef __BOOT_H_INCLUDED__
#define __BOOT_H_INCLUDED__

//=============================================================================
// Inline function prototypes

//
// Initialize the boot loader switch
//
inline void bootInit(void)
{
#if BOOT_SUPPORT_ENABLED
    // enable boot loader switch pullup resistor for input
    BOOT_SWITCH_PORT_DD &= ~(1<<BOOT_SWITCH_BIT);   // input
    BOOT_SWITCH_PORT_OUT |= (1<<BOOT_SWITCH_BIT);   // enable pullup
#endif
}

//
// Check if boot jump requested
//
inline char bootRequest(void)
{
#if BOOT_SUPPORT_ENABLED
    return (!(BOOT_SWITCH_PORT_IN & (1<<BOOT_SWITCH_BIT)));
#else
    return 0;
#endif
}

//
// Jump to boot loader (disable interface interrupts before is a must)
//
inline void bootJump(void)
{
#if BOOT_SUPPORT_ENABLED
#if BOOT_VIA_WATCHDOG
    cli();
    wdInit();
    while (1) ;
#else
    void (*loader)(void) = ((void (*)())BOOT_START_ADDRESS);

    // prepare switch pin to simulate the keypress to enter boot
    BOOT_SWITCH_PORT_OUT &= ~(1<<BOOT_SWITCH_BIT);  // set to zero (to be safe - DO NOT SET TO 1)
    BOOT_SWITCH_PORT_DD |= (1<<BOOT_SWITCH_BIT);    // output
    ((void (*)())loader)();                         // jump to boot
#endif // BOOT_VIA_WATCHDOG
#endif // BOOT_SUPPORT_ENABLED
}

#endif  // __BOOT_H_INCLUDED__
