//=============================================================================
// Reflex RC USB device.
//
// PLEASE DO NOT ASK FOR REFLEX INTERFACE SOURCE OR BINARY CODE!
// This code will NEVER be released due to copyright issues.
// Support the author of Reflex - buy the original product.
//
// This module is left here as a sample how to replace
// the output interface using conditional compilation.
//
// $Id: out_reflex.c,v 1.3.2.4 2006/08/10 13:20:51 SOY Exp $
//=============================================================================

#include "common.h"

#if OUT_REFLEX

#error "REFLEX code is unavailable - buy the original product"

//=============================================================================
// Local variables

// USB report buffer
static uchar usbReport[MAX_CHANNELS];   // no Report ID used

//-----------------------------------------------------------------------------
// Reflex RC USB device HID report descriptor

#if (MAX_CHANNELS != 8)
#error  "You must update the usbHidReportDescriptor[] if (MAX_CHANNELS != 8)"
#endif

PROGMEM char usbHidReportDescriptor[USB_CFG_HID_REPORT_DESCRIPTOR_LENGTH] =
{
    // REFLEX HID Report descriptor
    // ...
};

//-----------------------------------------------------------------------------

//
// Build the USB report data using channel data in uS
//
// Calculates each report byte using the following:
//   - source data must be in 988..2011 uS values
//   - the result is packed using the Reflex's convention
//
static uchar *usbBuildReport(void)
{
    // REFLEX HID Report descriptor build code
    // ...
    // check if transmitter is on
    // build the USB report
    // copy channel data into temporary buffer
    // build common part of report
    // build channel group-specific part of report
    // checksum magic
    // add flags, toggle channel group Id for next run

    // return the address of buffer
    return &usbReport[0];
}

//-----------------------------------------------------------------------------

//
// USB setup request processing
//
uchar usbFunctionSetup(uchar data[8])
{
    usbRequest_t *rq = (void *)data;

    if ((rq->bmRequestType & USBRQ_TYPE_MASK) == USBRQ_TYPE_CLASS)
    {
        // Return the report if host requests it without USB interrupt
        if (rq->bRequest == USBRQ_HID_GET_REPORT)
        {
            // wValue: ReportType (highbyte), ReportID (lowbyte)
            // we only have one report type, so don't look at wValue
            usbMsgPtr = usbBuildReport();
            return sizeof(usbReport);
        }
    }
    return 0;
}

//-----------------------------------------------------------------------------

//
// Check if the USB Interrupt In point buffer is empty and return
// the data buffer for the following host request via USB interrupt
//
void outSendData(void)
{
    if (usbInterruptIsReady())
    {
        // fill in the report buffer and return the
        // data pointer (Report ID is not used)
        usbSetInterrupt(usbBuildReport(), sizeof(usbReport));
    }
}

#endif  // OUT_REFLEX
