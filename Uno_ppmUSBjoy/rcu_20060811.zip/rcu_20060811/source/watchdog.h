//=============================================================================
// Watchdog operation.
//
// $Id: watchdog.h,v 1.4.2.2 2006/07/20 20:08:42 SOY Exp $
//=============================================================================

#ifndef __WATCHDOG_H_INCLUDED__
#define __WATCHDOG_H_INCLUDED__

//=============================================================================
// Inline function prototypes

//
// Initialize watchdog timer
//
inline void wdInit(void)
{
#if defined(__IOM16_H) || defined(__IOM32_H)
    WDTCR = (7 << WDP0) | (1 << WDE);
#else
    WDTCR = (1 << WDCE) | (1 << WDE);
#endif
    WDTCR = (7 << WDP0) | (1 << WDE);
}

//
// Reset watchdog timer
//
inline void wdReset(void)
{
    wdt_reset();
}

#endif  // __WATCHDOG_H_INCLUDED__
