#include "gamepad.h"

Gamepad *n64GetGamepad(void);

