﻿┌─┐
│A│
└─┘
To put the new firmware into AT90USB162 flash ROM using
pre-programmed Atmel bootloader:

* When you use “dfu-programmer” (small third-party command-line utility):

* When you use Atmel Flip:

h#s 140117
