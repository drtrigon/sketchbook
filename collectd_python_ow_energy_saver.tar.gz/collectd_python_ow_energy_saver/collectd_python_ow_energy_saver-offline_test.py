#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Logging script for Yun SHT31 (Arduino IDE) and ESP8266 SHT31 (MicroPython).
"""

# http://192.168.11.41:8080/mediawiki/index.php/OwnCloud_Raspberry_PI_server

# http://192.168.11.41:8080/mediawiki/index.php/OwnCloud_Raspberry_PI_server
# ursin@ThinkPad-T440-ursin:/data/03Tools/fabric/raspberrypi$ fab dump_rrd:table-1wire-current/gauge-26.EAA540010000_MS-TC.rrd
# ursin@ThinkPad-T440-ursin:/data/03Tools/fabric/raspberrypi$ cp rrd_dump ~/Downloads/gauge-26.EAA540010000_MS-TC.rrd_dump.xml

# https://stackoverflow.com/questions/1912434/how-do-i-parse-xml-in-python
# https://docs.python.org/2/library/xml.etree.elementtree.html

# https://stackoverflow.com/questions/13728392/moving-average-or-running-mean
# https://docs.scipy.org/doc/numpy-1.13.0/reference/generated/numpy.convolve.html

# https://en.wikipedia.org/wiki/Standard_deviation

import xml.etree.ElementTree

import matplotlib.pyplot as plt
import numpy as np

# https://stackoverflow.com/questions/42014687/histogram-plotting-attributeerror-max-must-be-larger-than-min-in-range-paramet/42016178#42016178
def norm(H1):
    newH1 = H1[~np.isnan(H1)]
    return np.apply_along_axis(func1d=lambda x: x/np.max(newH1), arr=newH1, axis=0)

e = xml.etree.ElementTree.parse('gauge-26.EAA540010000_MS-TC.rrd_dump.xml').getroot()

data = []
t = 0
#for rra in e.findall('rra'):
for rra in e.findall('rra')[0:1]:
    pdp_per_row = float(rra.findall('pdp_per_row')[0].text)
    print rra.findall('cf')[0].text, pdp_per_row
    for row in rra.findall('database')[0].findall('row'):
#        print t, row.findall('v')[0].text
        data.append( (t, float(row.findall('v')[0].text)) )
        t += pdp_per_row

data = np.array(data)
#mean = data[:,1].mean()
N = 10
mean = np.convolve(data[:,1], np.ones((N,))/N, mode='same')
std = np.convolve(((data[:,1] - mean)**2), np.ones((N,))/N, mode='same')
#print data

#plt.plot(data[:,0], data[:,1])  # current vs. time
#plt.plot(data[:,0], mean)  # 
#plt.plot(data[:,1], mean)  # 
#plt.plot(data[:,0], std)  # 
#plt.plot(data[:,1], std)  # 
plt.plot(mean, std)  # 
#plt.hist(data[:,1])
#plt.hist(norm(data[:,1]))
#plt.hist(norm(mean))
#plt.hist(norm(std))

#fuzzy = lambda x, r, c: np.int_(((x - r[0])/(r[1] - r[0])) * c)
fuzzy = lambda x, r, c: np.floor(((x - r[0])/(r[1] - r[0])) * c)  # np.floor instead of np.int_ for 'nan' handling
andf  = lambda x, y: np.min([x, y], axis=0)
orf   = lambda x, y: np.max([x, y], axis=0)
#mean = mean[~np.isnan(mean)]
#std = std[~np.isnan(std)]
#print np.min(mean), np.max(mean)
#print np.min(std), np.max(std)
#print fuzzy(mean, (0.100, 0.21), 6)
#print fuzzy(std, (0.0, 0.00025), 10)
##plt.hist(fuzzy(std, (0.0, 0.00025), 10))

#a = np.arange(0.0, 0.00025, 0.00001)
#b = fuzzy(a, (0.0, 0.00025), 10)
#for i, v in enumerate(b):
#    print i, a[i], v

# TODO: was ist alles angeschlossen?

dict_mean = {0: 'off', 1: 'deep-sleep', 2: 'sleep', 3: 'low', 4: 'medium', 5: 'high', 6: 'higher'}
dict_std = {0: 'off', 1: 'very-stable', 2: 'stable', 3: 'low', 4: 'low', 5: 'medium', 6: 'medium', 7: 'high', 8: 'high', 9: 'higher'}
#fm = fuzzy(mean, (0.100, 0.21), 6)
fm = fuzzy(mean, (0.100, 0.23), 7)
fs = fuzzy(std, (0.0, 0.00025), 10)
#fs = fuzzy(std, (0.0, 0.020), 10)
fsorm = orf(fs, fm)
for i, _ in enumerate(mean):
    print i, std[i], mean[i], fs[i], fm[i], dict_std.get(fs[i], 'huge'), dict_mean.get(fm[i], 'huge'), fsorm[i]
    if not np.isnan(fsorm[i]):
        print "%i-%i-%i" % (fs[i], fm[i], fsorm[i])
    else:
        print "%s-%s-%s" % (fs[i], fm[i], fsorm[i])

plt.grid()

#plt.savefig("test.png")
plt.show()
