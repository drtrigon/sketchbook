#!/usr/bin/python
# -*- coding: utf-8 -*-

#  LoadPlugin python
#  # ...
#  <Plugin python>
#    ModulePath "/usr/lib/collectd/plugins/python"
#    LogTraces true
#    Interactive false
#    Import "collectd_python_ow_energy_saver"
#
#    #<Module spam>
#    #  spam "wonderful" "lovely"
#    #</Module>
#  </Plugin>

# http://192.168.11.41:8080/mediawiki/index.php/OwnCloud_Raspberry_PI_server
# http://www.spektrum.de/magazin/prinzipien-der-fuzzy-logic/820699

#print np.min(mean), np.max(mean)
#print np.min(std), np.max(std)
#print fuzzy(mean, (0.100, 0.21), 6)
#print fuzzy(std, (0.0, 0.00025), 10)
##plt.hist(fuzzy(std, (0.0, 0.00025), 10))

#a = np.arange(0.0, 0.00025, 0.00001)
#b = fuzzy(a, (0.0, 0.00025), 10)
#for i, v in enumerate(b):
#    print i, a[i], v

#plt.plot(mean, std)  # 

#plt.grid()

##plt.savefig("test.png")
#plt.show()

# TODO: was ist alles angeschlossen?

import urllib2
import time
import matplotlib.pyplot as plt

import numpy

# energy saver current threshold
# (minimum with dark TV screen is 0.110 - what is it during PC standby?)
thrs = 0.110
stab = 0.005
# number of point / time to consider
pts  = 10
#pts  = 30
tm   = 30  # 30 minutes
## energy/power sensor
#sens = ('table', 'gauge', '1wire-current', '26.EAA540010000_MS-TC')

#data_ow_energy_saver = [float('nan')]*pts
data_ow_energy_saver = []
data_ow_energy_saver_time_since_change = 0
data_ow_energy_saver_buffer_ok = False

# fuzzy logic
#f_var   = lambda variable, universe: (variable - universe[0])/(universe[1] - universe[0])  # 0..1 usually
f_var   = lambda variable, universe: numpy.min([numpy.max([(variable - universe[0])/(universe[1] - universe[0]), numpy.zeros(numpy.shape(variable))], axis=0), numpy.ones(numpy.shape(variable))-1e-12], axis=0)  # [0, 1)
f_fuzzy = lambda var, membership: numpy.floor(var * len(membership))  # np.floor instead of np.int_ for 'nan' handling
f_and   = lambda x, y: numpy.min([x, y], axis=0)
f_or    = lambda x, y: numpy.max([x, y], axis=0)

#universe_mean = (0.100, 0.23)
universe_mean = (0.100, 0.26)  # average current drawn
universe_std = (0.0, 0.020)    # fluctuations via stddev
universe_fft = (0.0, 0.040)    # fluctuations via fft
member_simple = {0: 'off', 1: 'low', 2: 'medium', 3: 'high', 4: 'huge'}

## https://stackoverflow.com/questions/9446387/how-to-retry-urllib2-request-when-fails
#@retry(urllib2.URLError, tries=3, delay=3, backoff=2)
#def urlopen_with_retry(url):
#    return urllib2.urlopen(url)

#plt.axis([0, 10, 0, 1])
plt.ylim([0., 5.])
plt.grid(True)
ax = plt.gca()
#ax.set_xticks([1., 2., 3., 4., 5.])
ax.set_yticks(range(0, 6))
plt.ion()
start = time.time()

while True:
    response = urllib2.urlopen('http://192.168.11.41:2121/26.EAA540010000')  # access via owhttpd
#    response = urlopen_with_retry('http://192.168.11.41:2121/26.EAA540010000')
    val = float('nan')
    for line in response.readlines():
        if '<TR><TD><B>VAD</B></TD>' in line:
            val = float(line.strip().strip('<TR>DBVA/'))

    # collectd data
    data_ow_energy_saver = data_ow_energy_saver[-(pts-1):] + [val]
    print data_ow_energy_saver

    # check collected data and calc average
    data_ow_energy_saver_buffer_ok = float(len(data_ow_energy_saver))/pts
#    if len(data_ow_energy_saver) < pts:
#        continue
    #val = sum(data_ow_energy_saver)/float(pts) 
    #val = max(data_ow_energy_saver)
    valm = numpy.mean(data_ow_energy_saver)
    vals = numpy.std(data_ow_energy_saver)

    print '--- --- --- OLD --- --- ---'

    print 'energy-saver-state:',
    print [float((valm < thrs) and (vals < stab))]

    print 'energy-saver-mean:',
    print [valm]

    print 'energy-saver-std:',
    print [vals]

    print '--- --- --- NEW --- --- ---'

    valf = numpy.mean(numpy.abs(numpy.fft.fft(data_ow_energy_saver))) - valm
    fm = f_fuzzy(f_var(valm, universe_mean), member_simple)
    fs = f_fuzzy(f_var(vals, universe_std), member_simple)
    ff = f_fuzzy(f_var(valf, universe_fft), member_simple)
    fsorm = f_or(fs, fm)

#    if (fs < 2):
    if (fsorm < 2):
        data_ow_energy_saver_time_since_change += 1  # minutes
    else:
        data_ow_energy_saver_time_since_change = 0
    stat = f_var(float(data_ow_energy_saver_time_since_change), (0, tm))

    print 'energy-saver-state:',
    print [stat], data_ow_energy_saver_time_since_change, data_ow_energy_saver_buffer_ok

    print 'energy-saver-mean:',
    print [valm], fm, member_simple.get(fm, 'na')

    print 'energy-saver-std:',
    print [vals], fs, member_simple.get(fs, 'na')

    print 'energy-saver-fft:',
    print [valf], ff, member_simple.get(ff, 'na')

    #try:
    #    (fs, fm, fsorm) = map(int, (fs, fm, fsorm))
    #except:
    #    #pass
    #    (fs, fm, fsorm) = ('?', '?', '?')
    #print "%s %s %s %s %s" % (int(data_ow_energy_saver_buffer_ok), fs, fm, fsorm, data_ow_energy_saver_time_since_change)
    print "%i %i %i %i %i" % (data_ow_energy_saver_buffer_ok, fs, fm, fsorm, stat)

    print '--- --- --- --- --- --- ---'

    plt.scatter([time.time()-start]*4, [fs, fm, fsorm, stat], color=['r', 'b', 'g', 'k'])
#    time.sleep(60.)  # collectd intervall
    plt.pause(60.)

